# Server setup — auto-generated from commands.txt
function timber:settings/toggle/slow_chop
function timber:settings/toggle/plant_sapling
function timber:settings/toggle/chop_down
function timber:settings/toggle/wooden_axe
function timber:settings/toggle/chop_fungi
scoreboard players set time_between_chops timber 0
scoreboard players set blocks_per_chop timber 5
scoreboard players set max_tree_size timber 128
function blazeandcave:config/item_rewards_off
function blazeandcave:config/intro_msg_off
function blazeandcave:config/scoreboard_bac_advancements
scoreboard objectives setdisplay list bac_advancements
difficulty easy
say Server setup complete!
